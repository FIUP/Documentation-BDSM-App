SWE-Notes
=========

Conterrà tutti gli appunti in LaTEX del corso di Ingegneria del Software.
